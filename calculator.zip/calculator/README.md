# Advanced Calculator (Python + Flask)

A scientific calculator web app built with Python and Flask. The backend does all the math, and the frontend is plain HTML, CSS and JavaScript.

![Advanced Calculator](screenshot.png)

## Features

- Basic operations: `+ − × ÷`, `%`, brackets
- Scientific functions: `sin`, `cos`, `tan` and their inverses, `log`, `ln`, `√`, `∛`, `x²`, `xʸ`, `n!`, `|x|`
- Constants: `π`, `e`
- DEG / RAD angle modes
- Memory keys (`MC`, `MR`, `M+`, `M−`) and `Ans` for the last result
- Clickable calculation history
- Keyboard support (numbers, operators, `Enter`, `Backspace`, `Esc`)
- Safe evaluation: expressions are parsed with Python's `ast` module instead of `eval()`, so only math is allowed

## Project structure

```
calculator/
├── app.py              # Flask server + calculation engine
├── templates/
│   └── index.html      # Calculator UI
└── screenshot.png
```

## Run it locally

```bash
git clone https://github.com/lahirudasun777/calculator.git
cd calculator
python3 -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000

## Desktop app

**Windows:** download `Calculator.exe` from the [Releases](https://github.com/lahirudasun777/calculator/releases) page and double-click it. No Python needed.

Run the desktop window from source:

```bash
pip install -r requirements.txt
python desktop.py
```

Build it yourself:

```bash
pip install pyinstaller
# Windows
pyinstaller --onefile --windowed --name Calculator --icon icon.ico --add-data "templates;templates" desktop.py
# macOS
pyinstaller --onefile --windowed --name Calculator --add-data "templates:templates" desktop.py
```

The result is in the `dist/` folder.

## API

`POST /api/calculate`

```json
{ "expression": "sin(30)×100", "angle_mode": "deg" }
```

Response:

```json
{ "ok": true, "result": "50" }
```

## Built with

- Python 3
- Flask
- HTML / CSS / JavaScript
