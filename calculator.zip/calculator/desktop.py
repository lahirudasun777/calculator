"""
Desktop launcher for the Advanced Calculator.

Starts the Flask server in the background and shows the calculator
in its own native window (no browser, no terminal needed).

Run directly:   python desktop.py
Build the app:  see README.md ("Build a desktop app")
"""

import socket
import threading
import time

import webview

from app import app


def find_free_port() -> int:
    """Ask the OS for a free port so we never clash with other apps."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def run_server(port: int) -> None:
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)


def wait_for_server(port: int, timeout: float = 10.0) -> None:
    """Wait until Flask is accepting connections before opening the window."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.1)


if __name__ == "__main__":
    port = find_free_port()
    threading.Thread(target=run_server, args=(port,), daemon=True).start()
    wait_for_server(port)

    webview.create_window(
        "Advanced Calculator",
        f"http://127.0.0.1:{port}",
        width=780,
        height=720,
        min_size=(480, 600),
        background_color="#0f172a",
    )
    webview.start()
